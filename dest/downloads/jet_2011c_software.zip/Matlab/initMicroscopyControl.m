% This is the function that you'll use to get started with Micromanager and
% MATLAB.
warning on;

disp('Welcome to Micro-LAB v.0.1beta');
addpath([pwd '\Functions'], ...
        [pwd '\Interfaces'], ...
        [pwd '\ImageProcessing'], ...
        [pwd '\Experiments'], '-begin');
return    
username = input('Enter your username.', 's');

if ~exist(sprintf('Users\\%s', username))
    fprintf('Creating Users\\%s path. This is where you should store your personal experiments!\n', username);
    mkdir('Users', username);
end

addpath(sprintf('%s\\Users\\%s', pwd, username));
cd(sprintf('%s\\Users\\%s', pwd, username));

% Open a diary file for today's experiments.
% 
% This is useful for looking back through all microscope properties that
% have been set during an experiment.
n = 0;
while 1
    n = n + 1;
    if ~exist(sprintf('%s_%d.out', date, n))
        diary(sprintf('%s_%d.out', date, n));
        break
    end
end

clear all
close all

% Initialize and load LEDs.
LEDs = LED_load;

% Load Micromanager
MM_load;
