function pos = MM_getXYZ(mc)
% function pos = MM_getXYZ(mc)
% 
% This function obtains the current XYZ stage position (and perfect focus 
% offset) as a 4-element numerical vector.
% 
% Input argument:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% Output argument:
% pos           -   A 1 x 4 position vector, consisting of the x
%                   coordinate, y coordinate, z coordinate, and perfect
%                   focus offset.

x = mc.getXPosition('XYStage');
y = mc.getYPosition('XYStage');
z = mc.getPosition('TIZDrive');
p = str2num(MM_getProperty(mc, 'TIPFSOffset', 'Position'));
pos = [x y z p];