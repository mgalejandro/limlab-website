function LED_stop(LEDs)
% A simple wrapper function that 'stops' the LEDs - if they are receiving a
% time-varying voltage, this function freezes them at their current state.
% 
% This function wraps the MATLAB DAQ toolbox function 'stop.'
stop(LEDs);