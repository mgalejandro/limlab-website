function [MosaicIM, BWfinal, fname, BWedge] = MM_getMosaicRegion(mc, LEDs, multiplier)
% function [MosaicIM, BWfinal, fname, BWedge] = MM_getMosaicRegion(mc, LEDs, multiplier)
% 
% This function automatically identifies the pixels that are inside the DMD
% ON pixel region. It works by illuminating the ON pixels with a bright 650
% nm light input, snapping an image of this field of view, and thresholding
% the image to identify pixels within the ON pixel region.
% 
% The resulting mask image is automatically saved in a file 
% MosaicRegion_##.mat, where ## refers to a two-digit number that is
% automatically incremented to the lowest unused number in the file's
% location.
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% LEDs          -   The analog output DAQ objects that operate the LEDs, 
%                   obtained by running LED_load.
% multiplier    -   A parameter that determines the intensity threshold
%                   separating the illuminated region from the background.
%                   Higher values lead to a more restricted definition of 
%                   the ON pixel region. This argument defaults to a value
%                   of 1.5 if not supplied by the user.
% 
% Output arguments:
% MosaicIM      -   The grayscale image representing the full
%                   field-of-view, including the ON and OFF pixel regions.
% BWfinal       -   The binary image representing the ON pixel region,
%                   where values of 1 correspond to pixels within the
%                   region, and values of 0 correspond to pixels outside.
% fname         -   The filename MosaicRegion_##.mat in which the current
%                   ON pixel region has been saved.
% BWedge        -   An image consisting of the boundary of the ON pixel
%                   region, used for troubleshooting and sanity-check
%                   purposes.

%% Default values for optional input arguments.

if nargin < 3 || isempty(multiplier)
    multiplier = 1.5;
end

%% Get Mosaic region

LED_setVoltage(LEDs, [2 0]); % Sets the 650 nm LED value to 2V
MM_setOpticalConfiguration(mc, '650-750') % Set the optical configuration to snap a transmitted light image.

figure(1)
MosaicIM = MM_snapImage(mc); % Snap an image
imshow(MosaicIM(:,end:-1:1), []) % Show the image
setLiveWindowPosition(1) % Set the image figure's position

% The function that processes the transmitted light image to identify the
% ON pixel region:
[BWfinal BWedge] = identifyMosaicBoundary(MosaicIM, multiplier);

LED_setVoltage(LEDs, [0 1]) % Set the 650 nm LED value to 0V and the 750 nm LED value to 1V

%% Increment filenames until there's one free, then save the mosaic image!
c = 0;
while 1
    c = c + 1;
    if exist(sprintf('MosaicRegion%0.2d.mat', c))
        continue
    else
        save(sprintf('MosaicRegion%0.2d.mat', c), 'BWfinal', 'MosaicIM');
        fname = sprintf('MosaicRegion%0.2d.mat', c);
        break
    end
end