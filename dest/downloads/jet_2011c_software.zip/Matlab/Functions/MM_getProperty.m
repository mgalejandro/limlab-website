function value = MM_getProperty(mc, device, property)
% function value = MM_getProperty(mc, device, property)
% 
% This function provides a simple wrapper on the Java method getProperty
% that can be run on the Micromanager microscope object 'mc.'
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% device        -   The microscope device whose property is being queried
%                   (e.g. 'TITIRF' for the Nikon TI microscope's TIRF 
%                   control).
% property      -   The property whose value is of interest (e.g. 
%                   'Position' for the current TIRF angle).
% 
% Example usage: 
% current_angle = MM_getProperty(mc, 'TITIRF', 'Position')
value = mc.getProperty(device, property);
