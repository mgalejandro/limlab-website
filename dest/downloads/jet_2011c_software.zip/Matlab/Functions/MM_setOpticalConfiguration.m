function MM_setOpticalConfiguration(mc, oc, angle)
% function MM_setOpticalConfiguration(mc, oc, angle)
% 
% This function operates the LMM5 laser launch, Sutter Lambda filter
% wheels, both Nikon TI dichroic turrets, the TIRF mirrors and angles, 
% and the camera to set optical configurations corresponding to 
% brightfield, epifluorescence, and TIRF microscopy.
% 
% Note that because the specific configuration of each microscope differs,
% these settings will need to be modified to be appropriate for the
% microscope being used.
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% oc            -   A text descriptor referring to the desired optical
%                   configuration. These are interpreted by a switch/case
%                   statement, so the list can be updated with new
%                   configurations as needed. Currently, supported
%                   configurations include:
%                   405TIRF       - Standard 405 TIRF imaging
%                   488TIRF       - Standard 488 TIRF imaging
%                   514TIRF       - Standard 514 TIRF imaging
%                   561TIRF       - Standard 561 TIRF imaging
%                   405TIRF-600bp - 405 TIRF with 650/750 light on sample
%                   444TIRF-600bp - 444 TIRF with 650/750 light on sample
%                   488TIRF-600bp - 488 TIRF with 650/750 light on sample
%                   514TIRF-600bp - 514 TIRF with 650/750 light on sample
%                   561TIRF-600bp - 561 TIRF with 650/750 light on sample
%                   DIC           - DIC imaging
%                   650-750       - 650/750 light mask imaging(brightfield)
%                   EPI-BFP       - Epifluorescence - BFP filter set
%                   EPI-CFP       - Epifluorescence - CFP filter set
%                   EPI-GFP       - Epifluorescence - GFP filter set
%                   EPI-YFP       - Epifluorescence - YFP filter set
%                   EPI-RFP       - Epifluorescence - RFP filter set
% angle         -   The TIRF angle to be used for any of the TIRF optical
%                   configurations. Default values will be used if this
%                   argument is not supplied.

MM_setProperty(mc, 'Camera', 'ReadoutRate', '5MHz 16bit');

% Make sure the stage movement is slow!
if str2num(char(MM_getProperty(mc, 'XYStage', 'Speed-S'))) ~= 3
    MM_setProperty(mc, 'XYStage', 'Speed-S', '3');
end

% sanity check to make ABSOLUTELY SURE the shutter is closed before
% switching configurations!
mc.setShutterOpen(0);

% Make sure the light path is right!
MM_setProperty(mc, 'TILightPath', 'State', '2');

switch oc
    case '405TIRF'
        if nargin < 3 || isempty(angle)
            angle = 20450;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 405nm-1', '30');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 405 dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','5');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 1
            MM_setProperty(mc, 'LMM5-Shutter','State','1');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
            
    case '488TIRF'
        if nargin < 3 || isempty(angle)
            angle = 21500;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 488nm-3', '40');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 488 dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','1');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 4
            MM_setProperty(mc, 'LMM5-Shutter','State','4');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
    
    case '514TIRF'
        if nargin < 3 || isempty(angle)
            angle = 19200; %last time=19200 
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 514nm-4', '20');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if str2num(MM_getProperty(mc, 'TITIRF', 'Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 514TIRF dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','0');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 8
            MM_setProperty(mc, 'LMM5-Shutter','State','8');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
        
        
        
    case '561TIRF'
        if nargin < 3 || isempty(angle)
            angle = 18500;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 561nm-5', '20');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 10
            MM_setProperty(mc, 'Camera','MultiplierGain','10');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if str2num(MM_getProperty(mc, 'TITIRF', 'Position')) ~= angle            
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle));
        end
        % Analyzer dichroic (don't let 514 through until you image!)
        MM_setProperty(mc, 'TIFilterBlock1','State','3');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 16
            MM_setProperty(mc, 'LMM5-Shutter','State','16');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
                
        
    case '405TIRF_600bp'
        if nargin < 3 || isempty(angle)
            angle = 20450;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 405nm-1', '15');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 405 dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','5');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 1
            MM_setProperty(mc, 'LMM5-Shutter','State','1');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '9');

    case '444TIRF_600bp'
        if nargin < 3 || isempty(angle)
            angle = 18700;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 444nm-2', '100');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 100
            MM_setProperty(mc, 'Camera','MultiplierGain','100');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 442 dichroic (0)
        MM_setProperty(mc, 'TIFilterBlock1','State','4');
        % Mosaic 650bp dichroic (5)
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 2
            MM_setProperty(mc, 'LMM5-Shutter','State','2');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '4');
    
    case '488TIRF_600bp'
        if nargin < 3 || isempty(angle)
            angle = 21500;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 488nm-3', '15');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % 488 dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','1');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 4
            MM_setProperty(mc, 'LMM5-Shutter','State','4');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
                
    
    case '514TIRF_600bp'
        if nargin < 3 || isempty(angle)
            angle = 19600; 
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 514nm-4', '20');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 50
            MM_setProperty(mc, 'Camera','MultiplierGain','50');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if javastr2matlabnum(mc.getProperty('TITIRF','Position')) ~= angle
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle)); 
        end
        % Set 514TIRF dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','0');
        % Set Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 8
            MM_setProperty(mc, 'LMM5-Shutter','State','8');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '5');
        
    case '561TIRF_600bp'
        if nargin < 3 || isempty(angle)
            angle = 19000;
        end
        mc.setExposure(100);
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'LMM5-Hub', 'Transmission (%) 561nm-5', '20');
        if ~strcmp(mc.getShutterDevice, 'LMM5-Shutter')
            mc.setShutterDevice('LMM5-Shutter')
        end
        if javastr2matlabnum(mc.getProperty('Camera','MultiplierGain')) ~= 1
            MM_setProperty(mc, 'Camera','MultiplierGain','1');
            MM_setProperty(mc, 'Core','AutoShutter','1');
        end
        % Set TIRF angle
        if str2num(MM_getProperty(mc, 'TITIRF', 'Position')) ~= angle            
            MM_setProperty(mc, 'TITIRF','Position',num2str(angle));
        end
        % Analyzer dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','3');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        % Set laser port to use
        if javastr2matlabnum(mc.getProperty('LMM5-Shutter', 'State')) ~= 16
            MM_setProperty(mc, 'LMM5-Shutter','State','16');
        end
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','In');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');

        
        
        
    case 'DIC'
        mc.setExposure(10);
        mc.setShutterDevice('Shutter-DIA')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','1');
        % Excitation Filter
        MM_setProperty(mc, 'TIFilterBlock1','State','2');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
        
        
        
    case '650-750'
        mc.setExposure(10);
        mc.setShutterDevice('Shutter-DIA')
        mc.setAutoShutter(0);
        MM_setProperty(mc, 'Camera','MultiplierGain','5');
        % Excitation Filter
        MM_setProperty(mc, 'TIFilterBlock1','State','2');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        % Set this property twice because of a strange (unidentified)
        % Micromanager bug for imaging in this configuration.
        MM_setProperty(mc, 'TIFilterBlock2','State','5');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
        
    case 'EPI-BFP'
        mc.setExposure(100);
        mc.setShutterDevice('Shutter-EPI')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','10');
        % Excitation Filter
        MM_setProperty(mc, 'Wheel-EPI','State','1');
        % Dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','5');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '9');
        
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','Out');
        
        
    case 'EPI-CFP'
        mc.setExposure(500);
        mc.setShutterDevice('Shutter-EPI')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','100');
        % Excitation Filter
        MM_setProperty(mc, 'Wheel-EPI','State','8');
        % Dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','4');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '4');
        
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','Out');
        
        
    case 'EPI-YFP'
        mc.setExposure(100);
        mc.setShutterDevice('Shutter-EPI')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','20');
        % Excitation Filter
        MM_setProperty(mc, 'Wheel-EPI','State','1');
        % Dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','0');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','Out');
                
        
    case 'EPI-GFP'
        mc.setExposure(100);
        mc.setShutterDevice('Shutter-EPI')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','10');
        % Excitation Filter
        MM_setProperty(mc, 'Wheel-EPI','State','1');
        % Dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','1');
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '2');
        
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','Out');
    
    
    case 'EPI-RFP'
        mc.setExposure(500);
        mc.setShutterDevice('Shutter-EPI')
        mc.setAutoShutter(1);
        MM_setProperty(mc, 'Camera','MultiplierGain','50');
        % Excitation Filter
        MM_setProperty(mc, 'Wheel-EPI','State','6');
        
        % Dichroic
        MM_setProperty(mc, 'TIFilterBlock1','State','3');
        
        % Mosaic 650bp dichroic
        MM_setProperty(mc, 'TIFilterBlock2','State','0');
        
        % Emission Filter
        MM_setProperty(mc, 'Wheel-Emission', 'State', '7');
        
        % set TIRF/EPI mirror position
        MM_setProperty(mc, 'TITIRF','Mirror','Out');        
    
    otherwise
        error('Error setting optical configuration to %s: this configuration does not exist!', oc);
end

% sanity check to make ABSOLUTELY SURE the shutter is closed after
% switching configurations!
mc.setShutterOpen(0);
