function LED_setVoltage(LEDs, v)
% function LED_setVoltage(LEDs, v)
% 
% This function sets the 650 nm and 750 nm LED voltages to a new constant
% level.
% 
% Input arguments
%   LEDs    -   the MATLAB Data Acquisition Toolbox object controlling both
%               the 650 nm and 750 nm LEDs (using a DT9854 analog output
%               controller).
%   v       -   a 2-element vector specifying the 650 and 750 nm voltages
%               (in that order). Values should range between 0-5V for the
%               DT9854 output controller.

if length(v) ~= 2
    disp('Voltage must be a vector of length 2 in [V650 V750] format!');
end

v = v(:)';

stop(LEDs);

set(LEDs, 'TriggerType', 'Manual');
set(LEDs, 'BufferingConfig', [128 2]);
set(LEDs, 'SampleRate', 64);
set(LEDs, 'RepeatOutput', 0);

try
    putdata(LEDs, ones(128,1)*v);
    LED_start(LEDs);
catch
    stop(LEDs);
    putdata(LEDs, ones(128,1)*v);
    LED_start(LEDs);
end

fprintf('650 = %g V\n750 = %g V\n', v(1), v(2));