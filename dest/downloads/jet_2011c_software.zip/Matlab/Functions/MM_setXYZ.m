function MM_setXYZ(mc, pos)
% function pos = MM_setXYZ(mc)
% 
% This function sets the XYZ stage position and perfect focus offset to a 
% desired value.
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% pos           -   A 1 x 4 position vector, consisting of the x
%                   coordinate, y coordinate, z coordinate, and perfect
%                   focus offset. This can be obtained by running
%                   pos = MM_getXYZ(mc) for any position.
% 
% Example usage:
% MM_setXYZ(mc, pos(i,:));
% where pos is a k x 4 vector consisting of the k positions that have been
% previously identified for analysis, and i is the integer index of the ith
% position.

pos0 = MM_getXYZ(mc); % The current position

% Set the perfect focus to 'off' before stage movement.
MM_setProperty(mc, 'TIPFSStatus', 'State', 'Off');

% For stage movement, be careful about z position! It is ideal to set the z 
% position to the lowest expected value BEFORE moving in x or y
% coordinates, to avoid the objective hitting the sample during stage
% movement. This is accomplished by comparing the initial and final z
% positions, and setting the lowest z position before XY stage movement.

if pos0(3) > pos(3)
    % If final z position is lower than initial z position, set to final z
    % position first, pause, then move in XY.
    mc.setPosition('TIZDrive', pos(3));
    
    pause(1)
    disp('Z stage movement done');
    
    mc.setXYPosition('XYStage', pos(1), pos(2));
    while(mc.systemBusy), pause(0.1), end
    disp('XY stage movement done');
    
else
    % If initial z position is lower than final z position, move in XY
    % first, then set z position.
    
    mc.setXYPosition('XYStage', pos(1), pos(2));
    while(mc.systemBusy), pause(0.1), end
    disp('XY stage movement done');
    
    mc.setPosition('TIZDrive', pos(3));
    pause(1)
    disp('Z stage movement done');
end

% Perfect focus can take a while - make sure you're done before moving on!
MM_setProperty(mc, 'TIPFSStatus', 'State', 'On');
while 1
    curStatus = MM_getProperty(mc, 'TIPFSStatus', 'Status');
    if strcmp(curStatus, 'Locked') || strcmp(curStatus, 'Lock Failed')
        break
    end
    pause(0.1);    
end
disp(sprintf('PFS Status: %s', char(curStatus)))

% Finally, set the PFS offset to the desired value:
MM_setProperty(mc, 'TIPFSOffset', 'Position', pos(4));