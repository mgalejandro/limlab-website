function LED_start(LEDs)
% This function uses MATLAB's DAQ toolbox to send a voltage to the LEDs and
% trigger them to turn on.
% 
% Because there are occasionally communication errors with the LEDs
% (leading to a failure to turn on), this function is structured as two
% nested try/catch statements to attempt turning the LEDs on three times.

try
    % Turn on the LEDs
    start(LEDs);
    trigger(LEDs);
catch
    % If that didn't work, stop them and try again.
    stop(LEDs);
    pause(1);
    try
        % Turn on the LEDs
        start(LEDs);
        trigger(LEDs);
    catch
        % If that didn't work, stop them and try again.
        stop(LEDs);
        pause(1);
        start(LEDs);
        trigger(LEDs);
    end
end