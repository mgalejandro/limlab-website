function [IM] = MM_snapImage(mc, toDisplay)
% function [IM] = MM_snapImage(mc, toDisplay)
% 
% This function snaps an image, and saves it as a 512 x 512 unsigned
% 8-bit integer matrix IM. It also has the option to display the image upon
% acquisition.
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% toDisplay     -   An optional logical argument to either display the
%                   snapped image or not.
% Output arguments:
% IM            -   The 512x512 image IM that was snapped by the camera.

%% Default values for optional input arguments.

if nargin < 2 || isempty(toDisplay)
    toDisplay = 1;
end

%%
% Call the Micromanager snapImage method.
mc.snapImage; 
% Grab the image from the camera buffer.
IM = mc.getImage; 
% Reshape the image to the appropriate rectangular size.
IM = reshape(IM,mc.getImageWidth, mc.getImageHeight)'; 

% 'Flip' the image left-to-right to have the same orientation as other
% software packages (e.g. Nikon Elements)
IM = IM(:, end:-1:1); 

% Display the image, or not!
if toDisplay
    figure(1)
    imshow(IM, []);
end
