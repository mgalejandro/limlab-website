function fcn = LED_constructBufferedInput(LEDs, V, toCycle)
% function fcn = LED_constructBufferedInput(LEDs, V, toCycle)
% 
% This function returns a function handle 'fcn' that, when called,
% sets the next set of 650 and 750 nm voltages set in V. These voltages can
% either be looped (if toCycle is true), or the final value can be held (if
% toCycle is false).
% 
% Input arguments
%   LEDs    -   the MATLAB Data Acquisition Toolbox object controlling both
%               the 650 nm and 750 nm LEDs (using a DT9854 analog output
%               controller).
%   V       -   A 2x1 cell array of voltages where V{1} is a set of 650 nm
%               voltages and V{2} is a set of 750 nm voltages.
%   toCycle -   should these voltages be repeated?
% 
% Output argument
%   fcn     -   The function handle that, when called, updates voltages.
%               This is especially useful in the context of a 'timer'
%               object (see Experiment_TimedAcquisition for an example of
%               how this can be used).


% If vector V, assume you're only modulating 1 row
if ~iscell(V) && numel(V) == length(V)
    V = {V};
end

% Set the SAMPLE_INDEX
SAMPLE_INDEX = 0;

% Return a handle to the buffered_input
fcn = @buffered_input;

    function buffered_input(~,~)
        % Increment the counter
        SAMPLE_INDEX = SAMPLE_INDEX + 1;
        
        % Initialize sampleBuffer
        sampleBuffer = zeros(1,2);
        
        for i = 1:length(V)
            if toCycle
                % Get the permuted current value for each channel!
                sampleBuffer(i) = V{i}(mod(SAMPLE_INDEX-1, length(V{i}))+1);
            else
                % Fix the final value
                sampleBuffer(i) = V{i}(min(SAMPLE_INDEX, length(V{i})));
            end
        end
        putsample(LEDs, sampleBuffer)
    end
end