function MM_setProperty(mc, device, property, value)
% function value = MM_setProperty(mc, device, property)
% 
% This function provides a wrapper on the Java method setProperty
% that can be run on the Micromanager microscope object 'mc.'
% It is made more complicated than MM_getProperty because it first checks
% what the current value of the property is (doing nothing if it is
% already set to the desired value), and also because it attempts to set
% the property a second time if it encounters an error during the first
% try.
% 
% Input arguments:
% mc            -   The Micromanager Java object that operates the 
%                   microscope, obtained by running MM_load.
% device        -   The microscope device whose property is being queried
%                   (e.g. 'TITIRF' for the Nikon TI microscope's TIRF 
%                   control).
% property      -   The property whose value is of interest (e.g. 
%                   'Position' for the current TIRF angle).
% 
% Example usage: 
% current_angle = MM_getProperty(mc, 'TITIRF', 'Position')

%% Property values MUST be supplied to Java methods as strings!
if isnumeric(value)
    value = num2str(value);
end

%% Check the current property value, and exit if no change is needed.

% What's the current value of the property?
curValue = mc.getProperty(device, property);
if isa(curValue, 'java.lang.String')
    curValue = curValue.toCharArray';
end

if strcmp(curValue, value) || str2double(curValue) == str2double(value)
    % don't have to do anything
    return
end

%% Set the property value

% A verbose output to describe what property is being set:
disp(sprintf('Setting %s-%s: %s.', device, property, value));

try
    % Attempt to set the property and wait for the device to be ready.
    mc.setProperty(device, property, value);
    mc.waitForDevice(device);
catch
    % If the 'set' command failed, attempt a second time. As this happens
    % infrequently, it's worth trying twice - I have never seen this fail a
    % second time.
    warning(sprintf('Setting %s-%s: %s failed. Trying again...', device, property, value))
    mc.setProperty(device, property, value);
    mc.waitForDevice(device);
end