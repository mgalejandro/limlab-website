function IM = Experiment_ImageSequence(mc, OCs, saveFile)
% function IM = Experiment_ImageSequence(mc, OCs, saveFile)
% 
% This function acquires images and saves them as well as their 
% time of acquisition in the array of structures IM.
% 
% It takes input arguments:
%   mc      -   the microscope Java object used by Micromanager
%               to control the microscope.
%   OCs     -   a list of optical configurations with which to
%               acquire images
% 
% Output arguments:
%   IM      -   an array of stuctures of size n x m, where n is the 
%               number of timepoints and m is the number of channels 
%               to image.
% 
% Each element IM(i,j) has fields
%   IM.IM   -   the image (a matrix of pixel intensities)
%   IM.t    -   the time at which the image was acquired

nImages = length(OCs);

IM = struct('t',        cell(1, length(nImages)), ...
            'IM',       cell(1, length(nImages)));

for j = 1:nImages
    MM_setOpticalConfiguration(mc, OCs{j});
    IM(1,j).IM = MM_snapImage(mc);
    IM(1,j).t  = clock;
end
if nargin >= 3 && ~isempty(saveFile)
    save(saveFile, 'IM');
end
