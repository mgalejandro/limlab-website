function tim = Experiment_TimedAcquisition(mc, pos, name, OCs, N, T)
% function tim = Experiment_TimedAcquisition(mc, pos, name, OCs, N, T)
% 
% This function creates a 'timer' object which starts a timed
% acquisition at multiple XYZ stage positions, using multiple
% optical configurations.
% 
% Input arguments:
%   mc      -   the microscope Java object used by Micromanager
%               to control the microscope.
%   pos     -   a nP x 4 matrix where each row pos(i,:) contains the 
%               x, y, z, and perfect focus settings for that position.
%   name    -   the filename to which results should be saved.
%   OCs     -   a list of optical configurations with which to
%               acquire images
%   N       -   the number of images to acquire
%   T       -   the amount of time between images, in seconds
% 
% Output arguments:
%   tim     -   a MATLAB timer object. When this timer is started,
%               images are acquired every T seconds. Any of the 
%               standard functions on timers are applicable
% 
% Example usage:
% tim = Experiment_TimedAcquisition(mc, MM_getXYZ(mc), 'savename', '405TIRF', 10, 1);
% start(tim) % Starts acquiring images!


% Get a handle to the function that the timer will call at each
% timepoint!
fcn = constructImageSequence(mc, pos, name, OCs, N);

% The 'timer' object, used for periodically calling the
% function that acquires images.
tim = timer('StartFcn',        'disp(''Acquisition starting...'')', ...
            'TimerFcn',        fcn, ...
            'StopFcn',         'disp(''Acquisition finished!'')', ...
            'Period',          T, ...
            'TasksToExecute',  N, ...
            'StartDelay',      0, ...
            'ExecutionMode',   'fixedRate');

end




function fcn = constructImageSequence(mc, pos, name, OCs, N)

i = 0; % Set counter to 0

% Return function handle to the function that will actually
% acquire images.
fcn = @seq;

% Number of positions and optical configurations to image.
nP = size(pos, 1);
nO = length(OCs);

% Initialize structure in which to save images
allIM = struct('t',        cell(N, nP, nO), ...
               'IM',       cell(N, nP, nO));

    function seq(~, ~) % Tildes because required arguments for timer callbacks are unused by this function
        
        % Call each time the 'timer' object is used. Increment the
        % timepoint counter and take images from each position.
        i = i + 1;            
        for k = 1:size(pos, 1)
            
            MM_setXYZ(mc, pos(k,:));
            tmpIM = Experiment_ImageSequence(mc, OCs);
            
            allIM(i,k,:) = tmpIM;
            IM = squeeze(allIM(:,k,:));
            save(sprintf('%s_Pos%0.3d', name, k), 'IM', 'OCs', 'N');
        end
    end
end