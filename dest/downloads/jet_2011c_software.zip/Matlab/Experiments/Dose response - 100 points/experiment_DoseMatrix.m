%% Initialize 10 x 10 matrix dose response experiment

% Build a 10 x 10 dose matrix
% 
% V650 and V750 are both logarithmically spaced from 
% 0.01 V to 2 V.
NSamples = 10; 
V650 = logspace(-2, log10(2), NSamples);
V750 = logspace(-2, log10(2), NSamples);
V650s = [];
V750s = [];
for i = 1:NSamples
    V650s = [V650s V650];
    V750s = [V750s V750(i)*ones(1,NSamples)];
end

% Permute these doses to be run in a random order.
% iV is the index into the list of random permutations
iV = randperm(100);

V650s = V650s(iV)';
V750s = V750s(iV)';

% Include a control light intensity every 10 datapoints 
% to control for any changes in recruitment over time.
V650s = [ V650s(1:10);   V650(9)
          V650s(11:20);  V650(9)
          V650s(21:30);  V650(9)
          V650s(31:40);  V650(9)
          V650s(41:50);  V650(9)
          V650s(51:60);  V650(9)
          V650s(61:70);  V650(9)
          V650s(71:80);  V650(9)
          V650s(81:90);  V650(9)
          V650s(91:100); V650(9)
        ];

V750s = [ V750s(1:10);   V750(9)
          V750s(11:20);  V750(9) 
          V750s(21:30);  V750(9)
          V750s(31:40);  V750(9)
          V750s(41:50);  V750(9)
          V750s(51:60);  V750(9)
          V750s(61:70);  V750(9)
          V750s(71:80);  V750(9)
          V750s(81:90);  V750(9)
          V750s(91:100); V750(9)
        ];

%% Run experiment
% Place a region of controlled size within the TIRF footprint of
% the cell of interest, and run this code block.

disp('Running dose response experiment...')

% Which channel to image?
imageChannels = {'405TIRF_600bp'};

% Amount of time to wait between timepoints
waitTime = 80; 

% Grab the image
IM = Experiment_VoltageSequenceNoFilterChange(mc, LEDs, V650s, V750s, imageChannels, waitTime, 'matrix_650_750');

% Save data
save full_matrix_650_750 V650s V750s IM waitTime imageChannels iV NSamples BWfinal MosaicIM;
