%%
% Get regions of the image corresponding to the location of 
% recruited PIF, and a 'background' region . The command roipoly() allows this region to be
% selected interactively.

load full_matrix_650_750;

% Pick an image slice with a clear image of the mosaic region, 
% or background
slice = IM{20};

L = min(min(IM{slice}));
U = max(max(IM{slice}));

% Roipoly works best on images comprised of unsigned 
% 8-bit integers.
BWfinal = roipoly(uint8((double(slice)-L)/(U-L)*255));
BWbkgd  = roipoly(uint8((double(slice)-L)/(U-L)*255));


% This is the 'reverse permutation' list of all Vi values.
% Thus, V650s(Vi) is the original V650s order. Same goes for images.
[tmp Vi] = sort(iV);

% Remove all 'control' images.
Vi(Vi > 10)  = Vi(Vi > 10) + 1;
Vi(Vi > 21)  = Vi(Vi > 21) + 1;
Vi(Vi > 32)  = Vi(Vi > 32) + 1;
Vi(Vi > 43)  = Vi(Vi > 43) + 1;
Vi(Vi > 54)  = Vi(Vi > 54) + 1;
Vi(Vi > 65)  = Vi(Vi > 65) + 1;
Vi(Vi > 76)  = Vi(Vi > 76) + 1;
Vi(Vi > 87)  = Vi(Vi > 87) + 1;
Vi(Vi > 98)  = Vi(Vi > 98) + 1;
Vi(Vi > 109) = Vi(Vi > 109) + 1;

IM_NoControlValues = IM(Vi);
IM_ControlValues   = IM(11:11:end);

IM_NoControlValues = reshape(IM_NoControlValues, 10, 10);
V650s_NoControlValues = reshape(V650s(Vi), 10, 10);
V750s_NoControlValues = reshape(V750s(Vi), 10, 10);

%% 'Interesting' values!
for i = 1:10
    for j = 1:10
        intensity(i,j) = mean(double(IM_NoControlValues{i,j}(BWfinal(:))));
        ibkgd(i,j) = mean(double(IM_NoControlValues{i,j}(BWbkgd(:))));
    end
end
isub = intensity-ibkgd;

%% 'Control' values
% You repeated the 1.11/1.11 voltage combination 10 times throughout the
% data collection to see what happened. What happened?
for i = 1:10
    iControl(i)     = mean(double(IM_ControlValues{i}(BWfinal(:))));
    iControlBkgd(i) = mean(double(IM_ControlValues{i}(BWbkgd(:))));
end
iControlSub = iControl-iControlBkgd;

%% Plot 3D heatmap!
figure(1)
pcolor(V650s_NoControlValues, V750s_NoControlValues, isub)
xlabel('650 Voltage')
ylabel('750 Voltage')
set(gca, 'YScale', 'log', 'XScale', 'log')
colormap gray

%% Plot control values over time
figure(2)
plot(iControlSub)

%% Take a look at two control values: #1 and #9
figure(3)
subplot(2,1,1)
imshow(IM_ControlValues{1}, [450 1000])
subplot(2,1,2)
imshow(IM_ControlValues{9}, [450 1000])

%%
figure(4)
for i = 1:10
    imshow(IM_ControlValues{i}, [450 1000])
    pause
end

%% 
clf
c = linspace(0.8, 0, length(isub));
for i = 1:length(isub)
    semilogx(V650, isub(:,i), 'Color', c(i)*[1 1 1])
    hold on
end
set(gca, 'XLim', [7e-3 3])
xlabel('650 Voltage')
ylabel('Recruited intensity')
