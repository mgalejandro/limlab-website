% Set feedback strength here.
phi = 2.5e-3;

%%
% Automatically identify where the Mosaic DMD square is located
[MosaicIM, BWfinal, MosaicFName, BWedge] = acquireMosaicRegion(mc, LEDs);

r = 0.03:0.02:0.1; % Exponential ramp rates - change 'curvature' of exp curve!

for q = 1:4 % For each exponential rate
    % Savefile name. NOTE that you should set 'i', the current position,
    % before running this script!
	prefix = sprintf('Pos%0.2d_ExpUp_%0.2d', i, q);
    
    %% Max recruitment intensity
    LED_setVoltage(LEDs, [1 0])
    MM_setOpticalConfiguration(mc, '405TIRF_600bp')
    pause(30)
    IMmax = MM_snapImage(mc);
    figure(1)
    imshow(IMmax, [])
    drawnow
    bkgdMax = getBackgroundIntensity(IMmax);
    Imax = mean(double(IMmax(BWfinal))) - bkgdMax

    %% Min recruitment intensity
    LED_setVoltage(LEDs, [0 1])
    MM_setOpticalConfiguration(mc, '405TIRF_600bp')
    pause(30)
    IMmin = MM_snapImage(mc);
    figure(1)
    imshow(IMmin, [])
    drawnow
    bkgdMin = getBackgroundIntensity(IMmin);
    Imin = mean(double(IMmin(BWfinal))) - bkgdMin
    
    %% Set recruitment intensity

    % Create exponential ramp in intensity
    a = (Imax-1.1*Imin) ./ (exp(65*r)-1);       b = 1.1*Imin - a;
    referenceIntensity = b(q) + a(q).*exp(r(q)*(0:65));
    bkgd = mean([bkgdMax bkgdMin]);
    
    %% Run control loop
    
    % Initialization
    IntErr  = 0;
    PropErr = 0;
    phi1 = phi;
    phi2 = phi;
    max650Voltage = 2;
    scaleVals = [300 1e3];
    samplingTime = 1;
    c = 0;
    clear intensity u650 IntErr PropErr

    % Loop
    while samplingTime*c/60 <= 1 % run for this many minutes
        c = c + 1;
        disp(sprintf('Loop %d', c))

        % Get image
        MM_setOpticalConfiguration(mc, '405TIRF_600bp')
        IM = MM_snapImage(mc);
        figure(1)
        imshow(IM, [])
        drawnow

        % Save image out
        saveas(1, sprintf('%s_%0.3d.fig',prefix, c)) % Save as MATLAB image
        im2tif(IM, [prefix '.tif'], scaleVals); % save as TIF

        % Process intensity value
        intensity(c) = mean(double(IM(BWfinal)));
        ibkgd        = intensity(c) - bkgd;

        % Get feedback-controlled input
        PropErr(c) = referenceIntensity(c+1) - ibkgd;
        if c == 1
            % For first timepoint
            IntErr = PropErr; 
        else
            % For later timepoints
            IntErr(c)  = IntErr(c-1) + (referenceIntensity(c+1) - ibkgd);
        end
        
        u650(c) = phi1*(PropErr(c)) + phi2*(IntErr(c)); % Add PI terms!
        u650(c) = max(u650(c), 0);              % Make sure positive voltage.
        u650(c) = min(u650(c), max650Voltage);  % Make sure less than max allowed voltage.

        % Plot current output
        figure(2)
        plotyy(1:c, [u650; phi1*PropErr; phi2*IntErr], 1:c, intensity-bkgd)
        drawnow

        % Save results so far
        save(prefix, 'intensity', 'bkgd', 'PropErr', 'IntErr', 'u650', 'phi1', 'phi2', 'referenceIntensity', 'max650Voltage', 'scaleVals');

        % Set new voltage
        LED_setVoltage(LEDs, [u650(c) 0.1]);

        % Pause until next timepoint
        pause(samplingTime);
    end
end