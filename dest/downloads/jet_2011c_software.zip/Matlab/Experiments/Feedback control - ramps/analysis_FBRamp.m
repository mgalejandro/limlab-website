% Set i and q for which ramp data you'd like to load!
load(sprintf('Pos%0.2d_ramp%0.2d', i, q));

% Total number of images
c = 61;

% Plot the control experiment results on two axes!
clf
[ax h1 h2] = plotyy(0:c, [0 u650; 0 phi1*PropErr; 0 phi2*IntErr], 1:c, intensity-bkgd);
set(ax(1), 'XLim', [0 65], 'YLim', [-0.1 1], 'YTick', [0:0.2:1])
set(ax(2), 'XLim', [0 65], 'YLim', [50 200], 'YTick', [50:50:200])
axes(ax(2))
hold on
plot(1:length(referenceIntensity), referenceIntensity, 'k--')
