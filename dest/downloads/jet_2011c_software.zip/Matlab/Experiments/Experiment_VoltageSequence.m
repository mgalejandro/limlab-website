function IM = Experiment_VoltageSequence(mc, LEDs, V650, V750, OCs, T, name, nopause)
% function IM = Experiment_VoltageSequence(mc, LEDs, V650, V750, OCs, T, name, nopause)
% 
% This function acquires images and saves them in a cell array IM.
% It is used 
% 
% It takes input arguments:
%   mc      -   the microscope Java object used by Micromanager
%               to control the microscope.
%   LEDs    -   the MATLAB Data Acquisition Toolbox object controlling both
%               the 650 nm and 750 nm LEDs (using a DT9854 analog output
%               controller).
%   V650    -   The sequence of 650 nm light voltages to apply (on DT9854
%               output channel 0).
%   V750    -   The sequence of 750 nm light voltages to apply (on DT9854
%               output channel 1).
%   OCs     -   a list of optical configurations with which to
%               acquire images
%   T       -   the time in seconds to pause between successive images.
%   name    -   filename to which the output structure IM should be saved.
%   nopause -   set to 1 to collect first image immediately; set to 0 to
%               wait T seconds before acquiring the first image.
% 
% Output arguments:
%   IM      -   an cell array of size n x m, where n is the 
%               number of timepoints and m is the number of channels 
%               to image.
% 
% Each element IM{i,j} contains the image (a matrix of pixel intensities)


if nargin < 8 || isempty(nopause)
    nopause = 0;
end
if nargin < 9 || isempty(switchChannels)
    switchChannels = 1;
end

nImages = length(OCs);
nVoltages = length(V650);

if length(T) == 1
    T = T*ones(1, nVoltages);
end

IM = cell(length(nVoltages), length(nImages));

for i = 1:nVoltages
    
    disp(sprintf('Acquiring image %d', i));
    
    LED_setVoltage(LEDs, [V650(i) V750(i)]);
    if i ~= 1 || ~nopause
        pause(T(i))
    end
    for j = 1:nImages
        MM_setOpticalConfiguration(mc, OCs{j});
        IM{i,j} = MM_snapImage(mc);
    end
    if nargin >= 7 && ~isempty(name)
        save(name, 'IM');
    end
end

