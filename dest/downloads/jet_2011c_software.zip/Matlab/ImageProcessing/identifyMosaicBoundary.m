function [BWfinal BWedge] = identifyMosaicBoundary(IM, multiplier)
% function [BWfinal BWedge] = identifyMosaicBoundary(IM, multiplier)
% 
% This function uses a series of image processing commands to identify a
% rectangular region that is defined by a sharp gradient on all four sides,
% characteristic of the ON pixel region used in all experiments for this
% work.
% 
% Input arguments:
% IM            -   The grayscale image representing the full
%                   field-of-view, including the ON and OFF pixel regions.
% multiplier    -   A parameter that determines the intensity threshold
%                   separating the illuminated region from the background.
%                   Higher values lead to a more restricted definition of 
%                   the ON pixel region. This argument defaults to a value
%                   of 1.5 if not supplied by the user.
% 
% Output arguments:
% BWfinal       -   The binary image representing the ON pixel region,
%                   where values of 1 correspond to pixels within the
%                   region, and values of 0 correspond to pixels outside.
% BWedge        -   An image consisting of the boundary of the ON pixel
%                   region, used for troubleshooting and sanity-check
%                   purposes.

%% Default values for optional input arguments.

if nargin < 2 || isempty(multiplier)
    multiplier = 1.5;
end

%% Image processing to identify the ON pixel region.

maxIM = max(IM, [], 3);

% Find 'edges' in in the image using a Sobel filter with threshold.
[junk threshold] = edge(maxIM, 'sobel'); 
BWs = edge(maxIM,'sobel', threshold*multiplier);

% Find horizontal and vertical lines in the edge-detected image using image
% dilation with a vertical or horizontal structuring element.
se90 = strel('line', 3, 90);
se0 = strel('line', 3, 0);
BWsdil = imdilate(BWs, [se90 se0]);

% Fill 'holes' in the dilated image to fill in any objects that are
% bordered by the dilated image identified above.
BWdfill = imfill(BWsdil, 'holes');

% Run a series of erosions and openings to remove any spurious objects that
% might have been identified by the above procedure. Note that this is not
% necessarily the best (or only) way to do this, but works well for our
% purposes.
seD = strel('diamond',1);
BWfinal = imerode(BWdfill,seD);
BWfinal = imerode(BWfinal,seD);

seSq = strel('square', 10);
BWfinal = imopen(BWfinal, seSq);

seD = strel('square',15);
BWfinal = imerode(BWfinal,seD);

% Collect output arguments, including the 'final' ON pixel region image
% (BWfinal) and the boundary of this region (BWedge).
BWedge = imdilate(bwperim(BWfinal), [se90 se0]);
BWfinal = logical(BWfinal);
BWedge = logical(BWedge);
