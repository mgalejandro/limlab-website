function bkgd = getBackgroundIntensity(IM)
% This function quickly estimates the background intensity of an image,
% assuming that the background occupies the majority of the image (and thus
% represents the mode of an intensity histogram for the image).

IM = double(IM(:));

Imin = min(IM);
Imax = max(IM);

bins = linspace(Imin-1, Imax+1, 5e1);
[y x] = hist(IM, bins);

% Sanity check: you can plot this histogram and see if it looks OK
% plot(x,y)
% pause


bkgd = x(find(y == max(y), 1, 'first'));