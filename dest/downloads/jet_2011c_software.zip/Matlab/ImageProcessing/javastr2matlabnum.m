function outnum = javastr2matlabnum(instr)
% function outnum = javastr2matlabnum(instr)
% 
% This function take the input Java string 'instr' and converts it to a
% MATLAB numeric value 'outnum'. It is a simple wrapper on the toCharArray
% Java method, and uses the MATLAB function str2num.

outnum = str2num(instr.toCharArray');