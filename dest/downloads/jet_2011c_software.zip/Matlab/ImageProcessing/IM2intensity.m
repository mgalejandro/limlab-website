function intensity = IM2intensity(IM, mask)
% function intensity = IM2intensity(IM, mask)
% 
% This function takes a multidimensional cell array of images and a logical 
% mask matrix of the same size as each image, and returns a
% multidimensional array of mean intensities for the masked pixels in each
% image.
% 
% Input arguments:
% IM            -   A cell array of images, each of the same size (and the
%                   same size as the mask image).
% mask          -   A binary mask representing the pixels from which to
%                   compute the mean intensity.
% Output arguments:
% intensity     -   A multidimensional vector the same size as IM, where
%                   each entry represents the mean intensity of the
%                   mask region in the corresponding image from IM.

intensity = zeros(size(IM));

if iscell(IM)
    % Compute the mean intensity of the masked region for each image in IM.
    for i = 1:numel(IM)
        intensity(i) = mean(double(IM{i}(mask)));
    end
else
    % This function can also be called on a structure of images, in which
    % each contains a field 'IM' containing the image data.
    for i = 1:numel(IM)
        intensity(i) = mean(double(IM(i).IM(mask)));
    end
end
