function bkgd = getBackgroundIntensities(IMcell)
% This function acts as a wrapper on getBackgroundIntensity, which operates
% on a single image. In contrast, getBackgroundIntensities operates on an 
% n-dimensional cell array of images.

bkgd = zeros(size(IMcell));
for i = 1:numel(IMcell)
    bkgd(i) = getBackgroundIntensity(IMcell{i});
end
