% Unload all devices before shutting down
mc.unloadAllDevices;
diary off