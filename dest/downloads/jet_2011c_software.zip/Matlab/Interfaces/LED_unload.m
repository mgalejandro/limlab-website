function LED_unload(LEDs)

delete(LEDs)
daqreset
disp('LEDs unloaded successfully');
