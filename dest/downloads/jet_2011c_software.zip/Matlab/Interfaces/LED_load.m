function LEDs = LED_load
% function LEDs = LED_load
% 
% This function loads the two analog outputs supplied by the Data
% Translation DT9812 device. In our microscope configuration, these analog
% outputs control the intensity of the 650 and 750 nm LEDs, respectively.
% 
% The LEDs have a range of 0-5V, representing the valid range for values of
% the two analog output channels.

rehash toolboxcache
daqregister('C:\Program Files (x86)\Data Translation\DAQ Adaptor for MATLAB\Dtol.dll');

LEDs = analogoutput('dtol', 0); % Creates an analog output device.
set(LEDs, 'TriggerType', 'Manual'); % Require a software-controlled 'trigger' to turn on the LEDs
set(LEDs, 'BufferingConfig', [128 2]); % The number of samples that can be pre-loaded to the LEDs
set(LEDs, 'SampleRate', 64); % The number of samples per second sent to the LEDs

addchannel(LEDs, 0); % the 650 nm analog output channel
addchannel(LEDs, 1); % the 750 nm analog output channel