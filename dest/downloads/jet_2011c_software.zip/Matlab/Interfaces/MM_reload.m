% Load an instance of the MicroManager GUI and link it to the
% MATLAB-controlled microscope object.
import mmcorej.*;

gui = MMStudioPlugin;           % instantiate GUI object
gui.run('');                    % load GUI

disp('Press any key when configuration is fully loaded...')
pause

mc  = gui.getMMCoreInstance;    % microscope object

% note that the DIA voltage should be higher than might be the case at
% default (a value of 7V is good). How can you set this directly?

% The perfect focus and the DIA lamp are the unstable devices in the 
% matlab/micromanager interface. if you don't initialize either of these 
% devices, you don't run into any problems!
% 
% This means you must intialize the DIA lamp and perfect focus
% independently of the software interface, including setting the DIA 
% lamp voltage. It can be done before launching the MATLAB/MicroManager
% interface by running a prior instance of MicroManager independently.