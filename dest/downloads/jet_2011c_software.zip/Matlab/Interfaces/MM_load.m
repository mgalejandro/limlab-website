% Load an instance of the MicroManager GUI 'gui' and link it to the MATLAB-
% controlled microscope object 'mc'.
% 
% Both the 'gui' and 'mc' objects can then be controlled directly in MATLAB
% or by using wrapper functions written for this purpose.
% 
% To directly manipulate the Java objects, run methods using the syntax:
% 
% output = mc.fname(input1, input2, ...);
% 
% all 'input' arguments must be strings, and the 'output' will be a Java
% numeric, string, or string array variable.

import mmcorej.*;

gui = MMStudioPlugin;           % instantiate GUI object
gui.run('');                    % load GUI

disp('Press any key when configuration is fully loaded...')
pause

mc  = gui.getMMCoreInstance;    % microscope object
