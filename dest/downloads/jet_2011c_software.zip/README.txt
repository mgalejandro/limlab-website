OVERVIEW:

The software provided here is NOT meant to be a universally compatible
software package to be run 'out-of-the-box' on any microscope. Rather, it
is a set of MATLAB functions that allow the user to control a SPECIFIC
microscope - the Weiner lab's Nikon TI with a Mosaic II DMD, a 650 nm and
750 nm LED light source, and an LMM5 laser launch with at least 405, 514
and 561 lasers.

Nevertheless, the logic of microscopy control with MATLAB and
MicroManager and the algorithms underlying PI feedback control should be
of general interest and utility. Feel free to rewrite, modify, duplicate
or otherwise enjoy this code, but please credit me for this work and
please do not sell any derivatives of it!

Thank you, and enjoy!
-Jared Toettcher
jared.toettcher@gmail.com

BEFORE RUNNING:

Make sure you have MicroManager installed, and configured to work with
MATLAB. Exact instructions on how to set this up are available here:

http://valelab.ucsf.edu/~MM/MMwiki/index.php/Matlab_Configuration

Make sure you have a MicroManager configuration file set up for your
microscope! This can be done in MicroManager using the Tools->Hardware
Configuration Wizard.

Make sure you have a DMD and a DT9853 or DT9854 controller (or other DAQ 
toolbox compatible analog output controller) hooked up to your light 
source! Note that the LED control module can be used without a microscope
at all (by intializing LEDs and setting their voltages) - so be creative
with setting up other time-varying light inputs for your system of
interest :)

TO RUN:

Begin by running initMicroscopyControl. This will load LEDs, MicroManager
and add all functions to the paths.

The experiments to be run by the end user are present in the \Experiments
folder.

The \Functions folder contains the lower-level microscope manipulation
functions to set and get properties from the microscope objects, snap
images, change optical configurations, and set/get stage positions.

The \ImageProcessing folder contains code snippets to manipulate the
images acquired, such as identifying the Mosaic region, running
background subtraction, etc.

The \Interfaces folder contains the load/unload functions for the LEDs
and MicroManager.
